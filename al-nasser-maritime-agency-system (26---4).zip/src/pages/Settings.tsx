import React, { useEffect, useState } from 'react';
import { api } from '../api';
import { Settings as SettingsIcon, Save, Image as ImageIcon, Loader2, Database, FileSpreadsheet, Upload } from 'lucide-react';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

export default function Settings() {
  const [settings, setSettings] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    api.get('/settings').then(data => {
        setSettings(data);
        setIsLoading(false);
    });
  }, []);

  const handleBackup = async () => {
    setIsLoading(true);
    try {
      const endpoints = ['/ships', '/bills', '/operations', '/customs', '/freezone', '/deposits', '/exits', '/cars', '/headings', '/users', '/settings', '/invoices'];
      const data = await Promise.all(endpoints.map(endpoint => api.get(endpoint).catch(() => [])));
      
      const workbook = XLSX.utils.book_new();
      
      endpoints.forEach((endpoint, index) => {
        const sheetName = endpoint.replace('/', '');
        let items = Array.isArray(data[index]) ? data[index] : [data[index]];
        
        // Sanitize data for Excel: truncate strings longer than 32,767 characters
        const sanitizedItems = items.map((item: any) => {
          const newItem = { ...item };
          Object.keys(newItem).forEach(key => {
            if (typeof newItem[key] === 'string' && newItem[key].length > 32700) {
              newItem[key] = newItem[key].substring(0, 32700) + '... (truncated)';
            }
          });
          return newItem;
        });

        if (sanitizedItems.length > 0) {
          const worksheet = XLSX.utils.json_to_sheet(sanitizedItems);
          XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
        }
      });
      
      const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8' });
      saveAs(blob, `backup_${new Date().toISOString().split('T')[0]}.xlsx`);
    } catch (error) {
      console.error('Backup error:', error);
      alert('حدث خطأ أثناء أخذ النسخة الاحتياطية');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRestore = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm('سيتم استبدال جميع البيانات الحالية بالبيانات الموجودة في الملف. هل أنت متأكد؟')) return;

    setIsLoading(true);
    try {
      const reader = new FileReader();
      reader.onload = async (event) => {
        const data = event.target?.result;
        const workbook = XLSX.read(data, { type: 'array' });
        
        for (const sheetName of workbook.SheetNames) {
          const records = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
          if (records.length > 0) {
            try {
              await api.post('/restore', { table: sheetName, records });
              console.log(`Restored ${sheetName}`);
            } catch (err) {
              console.error(`Error restoring ${sheetName}:`, err);
            }
          }
        }
        alert('تمت استعادة البيانات بنجاح');
        window.location.reload();
      };
      reader.readAsArrayBuffer(file);
    } catch (error) {
      console.error('Restore error:', error);
      alert('حدث خطأ أثناء استعادة البيانات');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
        await api.post('/settings', settings);
        alert('تم حفظ الإعدادات بنجاح');
    } catch (e) {
        alert('خطأ أثناء الحفظ');
    } finally {
        setIsSaving(false);
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
            setSettings({ ...settings, logo: reader.result as string });
        };
        reader.readAsDataURL(file);
    }
  };

  if (isLoading) return <div className="flex items-center justify-center p-20"><Loader2 className="animate-spin text-primary" size={40} /></div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center gap-3">
        <div className="p-3 bg-primary/10 rounded-2xl text-primary">
            <SettingsIcon size={28} />
        </div>
        <h2 className="text-3xl font-bold">إعدادات النظام</h2>
      </div>

      <div className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold mb-2">النسخ الاحتياطي والأرشفة</h3>
          <p className="text-sm text-gray-500 font-bold">يمكنك أخذ نسخة احتياطية من البيانات (إكسل) أو استعادة البيانات من ملف إكسل مأخوذ مسبقاً</p>
        </div>
        <div className="flex gap-4">
            <button 
                onClick={handleBackup}
                disabled={isLoading}
                className="bg-emerald-600 text-white px-8 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/20 hover:bg-emerald-700 transition-all disabled:opacity-50"
            >
                <FileSpreadsheet size={20} />
                نسخة إكسل
            </button>
            <label className="bg-primary text-white px-8 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-primary/20 hover:opacity-90 transition-all cursor-pointer">
                <Upload size={20} />
                استعادة من إكسل
                <input type="file" hidden accept=".xlsx" onChange={handleRestore} disabled={isLoading} />
            </label>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-8 space-y-8">
            <div className="flex flex-col md:flex-row gap-8 items-start">
                <div className="space-y-4 flex flex-col items-center">
                    <div className="w-40 h-40 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200 flex items-center justify-center overflow-hidden relative group">
                        {settings.logo ? (
                            <img src={settings.logo} className="w-full h-full object-contain" alt="Logo" />
                        ) : (
                            <ImageIcon size={40} className="text-gray-300" />
                        )}
                        <label className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer text-white text-xs font-bold">
                            تغيير الشعار
                            <input type="file" hidden accept="image/*" onChange={handleLogoChange} />
                        </label>
                    </div>
                    <p className="text-xs text-gray-400 font-bold">شعار الوكالة</p>
                </div>

                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
                    <div className="space-y-1">
                        <label className="text-sm font-bold text-gray-600 mr-2">اسم الوكالة</label>
                        <input 
                            value={settings.name || ''} 
                            onChange={e => setSettings({...settings, name: e.target.value})}
                            required
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-primary transition-all"
                        />
                    </div>
                    <div className="space-y-1">
                        <label className="text-sm font-bold text-gray-600 mr-2">العنوان</label>
                        <input 
                            value={settings.address || ''} 
                            onChange={e => setSettings({...settings, address: e.target.value})}
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-primary transition-all"
                        />
                    </div>
                    <div className="space-y-1">
                        <label className="text-sm font-bold text-gray-600 mr-2">رقم الهاتف</label>
                        <input 
                            value={settings.phone || ''} 
                            dir="ltr"
                            onChange={e => setSettings({...settings, phone: e.target.value})}
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-primary transition-all"
                        />
                    </div>
                    <div className="space-y-1">
                        <label className="text-sm font-bold text-gray-600 mr-2">رقم الموبايل</label>
                        <input 
                            value={settings.mobile || ''} 
                            dir="ltr"
                            onChange={e => setSettings({...settings, mobile: e.target.value})}
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-primary transition-all"
                        />
                    </div>
                    <div className="space-y-1">
                        <label className="text-sm font-bold text-gray-600 mr-2">الموقع الإلكتروني</label>
                        <input 
                            value={settings.web || ''} 
                            dir="ltr"
                            onChange={e => setSettings({...settings, web: e.target.value})}
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-primary transition-all"
                        />
                    </div>
                    <div className="space-y-1">
                        <label className="text-sm font-bold text-gray-600 mr-2">فيسبوك</label>
                        <input 
                            value={settings.facebook || ''} 
                            dir="ltr"
                            onChange={e => setSettings({...settings, facebook: e.target.value})}
                            className="w-full p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:border-primary transition-all"
                        />
                    </div>
                </div>
            </div>
        </div>
        <div className="p-6 bg-gray-50 border-t border-gray-100 flex justify-end">
            <button 
                type="submit" 
                disabled={isSaving}
                className="bg-primary text-white px-8 py-3 rounded-2xl font-bold flex items-center gap-2 shadow-lg shadow-primary/20 hover:bg-primary/95 transition-all disabled:opacity-50"
            >
                {isSaving ? <Loader2 size={20} className="animate-spin" /> : <Save size={20} />}
                حفظ الإعدادات
            </button>
        </div>
      </form>
    </div>
  );
}
